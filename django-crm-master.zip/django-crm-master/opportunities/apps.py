from django.apps import AppConfig


class OpportunitiesConfig(AppConfig):
    name = 'opportunities'
